<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Step;
use App\Models\Task;
use Illuminate\Http\Request;

class StepController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($pid)
    {
        try{
            $steps = Step::where('project_id', $pid)->get();

            return response()->json([
                $steps
            ], 200);
        }catch (\Exception $e)
        {
            return $this->responseFail();
        }
    }
    public function getSteps($pid)
    {
        try{
            $steps = Step::with('tasks')->where('project_id', $pid)->get();

            return response()->json([
                $steps
            ], 200);
        }catch (\Exception $e)
        {
            return $this->responseFail();
        }
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request){
        try{
            $step= new Step();
            $step->project_id=$request->project_id;
            $step->task_status=$request->task_status;
            $step->step_order=$request->step_order;
            //dd($step);
            $step->save();

            //return $this->responseSuccess($step);

            return response()->json([
                $step
            ], 200);
        }catch (\Exception $e)
        {
            return $this->responseFail();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Step $step)
    {
        try{
           // dd('dd');
            //$step= Step::where('id', $id)->get();
            //dd($step);
         //   dd($request->all());
            $step->project_id=$request->project_id;
            $step->task_status=$request->task_status;
            $step->step_order=$request->step_order;
          // dd($step);
            $step->save();

            //return $this->responseSuccess($step);

            return response()->json([
                $step
            ], 200);
        }catch (\Exception $e)
        {
            return $this->responseFail();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try
        {
            $step=Step::find($id);
           // dd($step);
            if(!empty($step)){
                $tasks = Task::where('step_id', $id)->get();
                if ($tasks->isNotEmpty()){
                    foreach ($tasks as $task){
                        $task->delete();
                    }
                }
            }
            $step->delete();
            $msg="deleted";
            return response()->json([
                $msg
            ], 200);
        }catch (\Exception $e)
        {
            return $this->responseFail();
        }
    }
}
