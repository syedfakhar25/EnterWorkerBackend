<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Designation;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Illuminate\Http\Request;
use App\Http\Requests\Users\StoreUsersRequest;
use App\Http\Requests\Users\UpdateUsersRequest;
use App\Http\Traits\ApiMessagesTrait;
use Illuminate\Support\Facades\Hash;
use App\Http\Resources\UsersCollection;
use File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
class UsersController extends Controller
{
    use ApiMessagesTrait;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try
           {
            $users=new UsersCollection(User::latest()->get());

            return $this->responseSuccess($users);
        }catch (\Exception $e)
        {
            return $this->responseFail();
        }
    }

    public function userEmployees(Request $request){
        //dd('sjdb');
        $employees = DB::select(DB::raw("select  users.*, designations.designation_name from users join designations
                            on (users.designation_id = designations.id);"));
        foreach ($employees as $emp){
            $emp->img =  asset('user_images/' . $emp->img);
        }

        return response()->json([
            $employees
        ], 200);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
     try{
        // dd('here');
        // dd($request->designation_id);
         $designation_name  = Designation::select('designation_name')->where('id', $request->designation_id)->first();
         $d_name = $designation_name->designation_name;
       //     dd($d_name);
        $user= new User();
        $user->first_name=$request->first_name;
        $user->last_name=$request->last_name;
        $user->phone=$request->phone;
        $user->gender=$request->gender;
        $user->designation_id=$request->designation_id;
        $user->designation=$d_name;
        $user->email=$request->email;
        $user->password= Hash::make($request->password);
        $user->user_type=$request->user_type;
        if (!empty($request->img)) {
                $imageName = time() . '.' . $request->img->extension();
                $request->img->move(public_path('user_images'), $imageName);
                $user->img = $imageName;
            }
        //dd($user);
        $user->save();

        if($user->user_type==2){
            $role= Role::where('name','manager')->first();
            $user->assignRole($role);
        }
        if($user->user_type==3){
            $role= Role::where('name','employee')->first();
            $user->assignRole($role);
        }
        if($user->user_type==4){
            $role= Role::where('name','customer')->first();
            $user->assignRole($role);
        }
        $user->img=asset('user_images/' . $user->img);

        return $this->responseSuccess($user);
        }catch (\Exception $e)
        {
            return $this->responseFail();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
         try
            {
                $user->img=asset('user_images/' . $user->img);
              return $this->responseSuccess($user);
          }catch (\Exception $e)
          {
            return $this->responseFail();
          }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        // dd($user);
        try
            {
                $user->img=asset('user_images/' . $user->img);
              return $this->responseSuccess($user);
          }catch (\Exception $e)
          {
            return $this->responseFail();
          }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateUsersRequest $request,  User $user)
    {



            try{
        $designation_name  = Designation::select('name')->where(id, $request->designation_id)->first();
        $user->first_name=$request->first_name;
        $user->last_name=$request->last_name;
        $user->phone=$request->phone;
        $user->gender=$request->gender;
        $user->designation_id=$request->designation_id;
        $user->designation=$designation_name;
        $user->email=$request->email;
        $user->password= Hash::make($request->password);
        $user->user_type=$request->user_type;
        if (!empty($request->img)) {
            // $image = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAoHBwkHBgoJCAkLCwoMDxkQDw4ODx4WFxIZJCAmJSMgIyIoLTkwKCo2KyIjMkQyNjs9QEBAJjBGS0U+Sjk/QD3/2wBDAQsLCw8NDx0QEB09KSMpPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT3/wAARCABYAFgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2aiiigAooooAKKKKACiiigAooooAKKKKAI5547eMvIcD+dZE+rzOSIgI19epqPVJzLdsuflj+UD+dVURnYKgJY9AK+OzPN606ro0HZJ203bPRo4eKjzSJ/wC0br/nsfyFH9o3X/PY/kKX+zbr/nifzFH9m3X/ADyP5ivPtmX9/wD8mNf3Pl+AC/u2IAlYknA4FdAuQo3HJxzWdY6YYXEsxBcdFHatKvqMnw+Jp03PEN3eybvY4cRODaUClquqW+kWTXFyxwOFUdWPoK4i68d6lLKTbrDBH2XbuP4k1qeL9J1XVtQiFrbl7eJODvA+Y9ep+lc//wAIjrX/AD5H/v4v+NfaYKjhY01Ko02+72Pl8fXxkqjhRi1Fdk9Sb/hNdZ/57Rf9+hR/wmus/wDPaL/v0Kh/4RHWv+fI/wDfxf8AGnxeDdZkcKbZYx/eeRcD8q7GsEv5fwOFSzB/zfiXtJ8UazqOq21r5sZEjgNiIfd6n9KK6Lw94Zh0RTK7iW6cYL44Ueg/xorxcZVpSqfuUkl5bnv4GjWjT/fybb89iC8BW8mB/vmnWE6W92ryfdwQT6Vd1WyZz58YycfOB/OsmvzLF06uBxjlbZ3XnqfSU2qtOx0n2y3/AOe0f/fVL9st/wDntH/30K5qivR/1krfyL8TL6nHudUrK4ypBHqDS1zEM8lu+6JiD6djXQWlyt1AHHB6MPQ17OXZtTxr5GrS7f5HPWoOnr0J6ytU8R6fpLeXcSlpf+ecY3N+Pp+NP8QakdK0ae5THmAbY8/3jwP8fwryl5GkdnkYs7HLMTkk19RgMCsQnOex4WY5i8M1CC95noH/AAn2m/8APC6/75X/ABpV8e6czBRBdZJwPlX/ABrz2un8LeGZ7u8ivLuJo7aMh1DDBkI6celd1bA4WjByl+Z51DMcZXmoQt9x6DRS0V8+fTBVabT7ecksmGPdeKs0VnVo06y5akU15jjJxd0zP/saD+/J+Y/wpG0WEj5ZJAffBrQZgqlj0AzXOz3008hYuyjsqnAFeFmMMvwUVzUrt9EdVF1aj0kF3ZSWjDd8yHowqzo0hFw6dmXP5U6yna8SS1nO7K5Vj1FLo0LCSSRhwPl/HvXm4OhD65SrYa/LK+/S26Nqkn7OUZ7o1JYY502zRpIuc4ZQRVN49JiYrIlijDqGCA1y/jDxJMly2nWUhjVB+9dTgk/3Qa408nJ5NfpWGy2dSClKVrnyeLzWnTqOEY81up6yj6RGwZGsVYdCCgNT/wBo2f8Az92//fxf8a8ewPSjA9K3eUJ7zZzLO2tqa+89kiu7eZ9sU8Tt1wrgmiuP8BaVIskuoyJtQr5cWR97nk/piivJxNKNGo4Rd7Ht4StKvSVSStc7aiiiuc6RCAwIPQ1hz6VPHIRGu9OxBrdorhx2X0sakqm66o1pVZU9jP02wa2JklxvIwAO1XlRUGFAA9BTqK2w2Fp4amqdNaImc3N3Zzdz4IsLq5lnknud8rl2ww6k/So/+EB03/nvdf8AfS/4V1FFeksbXSspM4XgMM3dwRy//CA6b/z3uv8Avpf8KntPBOlW0gd1lnI6CVuPyGK6Gik8ZXas5sI4DDRd1BCKqooVQFUDAAGAKKWiuY6wooooAKKKKACiiigAooooAKKKKACiiigD/9k=";  // your base64 encoded


         $base64_image = $request->img; // your base64 encoded
    @list($type, $file_data) = explode(';', $base64_image);
    @list(, $file_data) = explode(',', $file_data);
    $imageName = time().'.'.'png';
    \File::put(public_path('user_images/').$imageName, base64_decode($file_data));
                $user->img = $imageName;
            }
        $user->save();
        $user->roles()->detach();
        if($user->user_type==2){
            $role= Role::where('name','manager')->first();
            $user->assignRole($role);
        }
        if($user->user_type==3){
            $role= Role::where('name','employee')->first();
            $user->assignRole($role);
        }
        if($user->user_type==4){
            $role= Role::where('name','customer')->first();
            $user->assignRole($role);
        }
        $user->img=asset('user_images/' . $user->img);
            return $this->responseSuccess($user);
        }catch (\Exception $e)
        {
            return $this->responseFail();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        try
            {
              $user->delete();
             $img_path = public_path('/user_images/').$user->image;
                if (File::exists($img_path)) {
                    File::delete($img_path);
                }
                $msg="deleted";
              return $this->responseSuccess($msg);
          }catch (\Exception $e)
          {
            return $this->responseFail();
          }
    }

     public function getallemployee()
    {
        try
           {
            $employee=new UsersCollection(User::where('user_type',3)->get());

            return $this->responseSuccess($employee);
        }catch (\Exception $e)
        {
            return $this->responseFail();
        }
    }
     public function getallcustomer()
    {
        try
           {
            $customers=new UsersCollection(User::where('user_type',4)->get());

            return $this->responseSuccess($customers);
        }catch (\Exception $e)
        {
            return $this->responseFail();
        }
    }
     public function getallmanagers()
    {
        try
           {
            $managers=new UsersCollection(User::where('user_type',2)->get());

            return $this->responseSuccess($managers);
        }catch (\Exception $e)
        {
            return $this->responseFail();
        }
    }
}
